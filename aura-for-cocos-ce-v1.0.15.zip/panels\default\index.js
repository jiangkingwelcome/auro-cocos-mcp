"use strict";var Z=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var te=Z((ue,ee)=>{"use strict";ee.exports={"tab.status":"状态","tab.control":"控制","tab.config":"互联","status.connection":"连接状态","status.endpoint":"服务端点 (Endpoint)","status.port":"监听端口 (Port)","status.project":"项目名称","status.path":"工作区路径","status.engine":"Cocos 引擎版本","status.clients":"已连接 AI 客户端","status.tools":"暴露可用工具数","status.actions":"可调用总 Action 数","status.uptime":"连续运行时长","status.online":"在线","status.offline":"离线","ctrl.title":"服务管理","ctrl.desc":"管理底层的 MCP 中继服务节点。","ctrl.start":"▶ 启动服务","ctrl.stop":"■ 停止服务","ctrl.restart":"↻ 重启服务 (Restart)","ctrl.tools_title":"工具开关","ctrl.tools_desc":"控制 AI 可调用的 MCP 工具。关闭后 AI 将无法看到该工具。","ctrl.tools_core":"(核心)","cfg.title":"IDE 协同配置","cfg.desc":"将当前 Cocos 环境桥接至 AI 编程助手。","cfg.inject":"注入配置","cfg.injecting":"⏳ 注入中…","cfg.ready":"配置已就绪","cfg.unready":"未检测到配置","cfg.hint":"本操作会将当前工作空间的端点合并写入对应 IDE 的 mcp.json，您需要在目标 IDE 中刷新或重启生效。","cfg.fail_ide":"配置失败: 无法识别目标 IDE","cfg.fail":"配置失败","cfg.timeout":"请求超时，请重试","tab.settings":"设置","settings.license_title":"License 授权","settings.license_desc":"管理 Pro 版 License Key 激活状态。","settings.activate":"激活","settings.license_hint":"输入 License Key 后点击激活，需要重启插件使 Pro 工具生效。","settings.license_activated":"License 已激活！重启插件后 Pro 工具将生效。","settings.license_invalid":"License Key 无效","settings.title":"安全与性能","settings.desc":"配置 MCP Bridge 的安全策略和性能参数。","settings.rate_limit":"速率限制 (请求/分钟)","settings.rate_limit_hint":"每分钟允许的最大请求数，范围 10–10000","settings.loopback":"本地回环限制","settings.loopback_hint":"开启时仅允许 127.0.0.1 / ::1 访问，关闭后允许任意 IP","settings.body_limit":"请求体大小限制","settings.body_limit_hint":"单次请求最大体积，范围 64KB–50MB","settings.rollback":"自动回滚","settings.rollback_hint":"开启时，原子操作失败将自动回滚已创建的临时节点","settings.reset":"恢复默认","settings.save":"保存设置","settings.saved":"设置已保存","settings.reset_done":"已恢复默认设置","settings.on":"开启","settings.off":"关闭","settings.warn_loopback":"⚠ 关闭回环限制将允许外部网络访问，请确保网络安全","tab.guide":"📖 指南","guide.title":"快速上手","guide.desc":"3 步完成从安装到 AI 驱动开发。","guide.step1_title":"确认服务在线","guide.step1_desc":"切到「状态」Tab，确认连接状态为 Online（绿灯）。若离线，切到「控制」Tab 点击启动。","guide.step2_title":"连接你的 AI IDE","guide.step2_desc":"切到「互联」Tab，点击你使用的 IDE 旁的「注入配置」按钮。然后在 IDE 中重启或刷新 MCP。","guide.step3_title":"开始对话","guide.step3_desc":"在 AI IDE 中直接用自然语言描述你想做的操作，AI 会自动调用 MCP 工具完成。参考下方示例。","guide.examples_title":"💬 AI 提示词示例","guide.examples_desc":"复制以下提示词到 AI IDE 中试试看。","guide.tag_scene":"场景","guide.tag_create":"创建","guide.tag_modify":"修改","guide.tag_ui":"UI","guide.tag_asset":"资产","guide.tag_prefab":"预制体","guide.prompt1":"查看当前场景的节点树结构","guide.prompt2":"在 Canvas 下创建一个按钮，文字为「开始游戏」","guide.prompt3":"把选中的节点移动到坐标 (200, 300)","guide.prompt4":"创建一个 ScrollView 列表，包含 5 个子项","guide.prompt5":"列出 assets/textures 目录下所有图片资源","guide.prompt6":"创建一个名为 Enemy 的预制体，包含 Sprite 和 BoxCollider2D 组件","guide.tips_title":"💡 使用小贴士","guide.tip1":"先选中节点再描述操作，AI 会自动作用于选中对象","guide.tip2":"遇到报错时 AI 会自动重试，无需手动干预","guide.tip3":"批量操作（如创建多个节点）用一句话描述，AI 会自动使用 batch 模式","guide.tip4":"所有写操作仅限本地 127.0.0.1，不会泄漏到外网","badge.community":"社区版","badge.pro":"Pro","badge.enterprise":"Enterprise","license.community_edition":"社区版 Community","license.pro_edition":"Pro Edition","license.enterprise_edition":"Enterprise Edition","license.free":"免费版","license.activated":"已激活","license.expired":"已过期","license.not_activated":"未激活","license.expiry_prefix":"有效期至","footer.sync":"🔄 同步状态","update.available":"🎉 新版本可用","update.current":"当前版本","update.latest":"最新版本","update.changelog":"更新内容","update.download":"立即下载","update.downloading":"下载中","update.verifying":"校验中...","update.install":"安装并重启","update.installing":"安装中...","update.done":"✅ 更新完成，请重启 Cocos Creator 生效","update.error":"更新失败","update.retry":"重试","update.notify":"有更新","update.breaking":"⚠ 重要更新，建议备份项目后升级","update.up_to_date":"已是最新版本"}});var se=Z((fe,ie)=>{"use strict";ie.exports={"tab.status":"Status","tab.control":"Control","tab.config":"Connect","status.connection":"Connection","status.endpoint":"Endpoint","status.port":"Port","status.project":"Project","status.path":"Workspace Path","status.engine":"Cocos Engine","status.clients":"AI Clients","status.tools":"Available Tools","status.actions":"Total Actions","status.uptime":"Uptime","status.online":"Online","status.offline":"Offline","ctrl.title":"Service Control","ctrl.desc":"Manage the underlying MCP relay service.","ctrl.start":"▶ Start","ctrl.stop":"■ Stop","ctrl.restart":"↻ Restart","ctrl.tools_title":"Tool Toggle","ctrl.tools_desc":"Enable or disable individual MCP tools. Disabled tools will be hidden from AI.","ctrl.tools_core":"(core)","cfg.title":"IDE Integration","cfg.desc":"Bridge this Cocos project to your AI coding assistant.","cfg.inject":"Inject Config","cfg.injecting":"⏳ Injecting…","cfg.ready":"Configured","cfg.unready":"Not configured","cfg.hint":"This writes the current endpoint into the target IDE's mcp.json. Restart or refresh the IDE to apply.","cfg.fail_ide":"Config failed: Cannot identify target IDE","cfg.fail":"Config failed","cfg.timeout":"Request timeout, please retry","tab.settings":"Settings","settings.license_title":"License","settings.license_desc":"Manage Pro edition license key activation.","settings.activate":"Activate","settings.license_hint":"Enter your License Key and click Activate. Restart the plugin for Pro tools to take effect.","settings.license_activated":"License activated! Restart the plugin for Pro tools to take effect.","settings.license_invalid":"Invalid license key","settings.title":"Security & Performance","settings.desc":"Configure MCP Bridge security policies and performance parameters.","settings.rate_limit":"Rate Limit (req/min)","settings.rate_limit_hint":"Max requests per minute, range 10–10000","settings.loopback":"Loopback Only","settings.loopback_hint":"When ON, only 127.0.0.1 / ::1 can connect. When OFF, any IP is allowed.","settings.body_limit":"Request Body Limit","settings.body_limit_hint":"Max request body size, range 64KB–50MB","settings.rollback":"Auto Rollback","settings.rollback_hint":"When ON, failed atomic operations will rollback temporary nodes automatically","settings.reset":"Reset to Default","settings.save":"Save Settings","settings.saved":"Settings saved","settings.reset_done":"Settings reset to defaults","settings.on":"ON","settings.off":"OFF","settings.warn_loopback":"⚠ Disabling loopback restriction allows external access. Ensure network security.","tab.guide":"📖 Guide","guide.title":"Quick Start","guide.desc":"3 steps from install to AI-driven development.","guide.step1_title":"Confirm Service Online","guide.step1_desc":'Go to "Status" tab, verify connection is Online (green). If offline, go to "Control" tab and click Start.',"guide.step2_title":"Connect Your AI IDE","guide.step2_desc":'Go to "Connect" tab, click "Inject Config" for your IDE. Then restart or refresh MCP in the IDE.',"guide.step3_title":"Start Chatting","guide.step3_desc":"Describe what you want in natural language in your AI IDE. The AI will call MCP tools automatically. See examples below.","guide.examples_title":"💬 AI Prompt Examples","guide.examples_desc":"Copy these prompts into your AI IDE to try.","guide.tag_scene":"Scene","guide.tag_create":"Create","guide.tag_modify":"Modify","guide.tag_ui":"UI","guide.tag_asset":"Asset","guide.tag_prefab":"Prefab","guide.prompt1":"Show the node tree of the current scene","guide.prompt2":'Create a button under Canvas with text "Start Game"',"guide.prompt3":"Move the selected node to position (200, 300)","guide.prompt4":"Create a ScrollView list with 5 items","guide.prompt5":"List all image assets under assets/textures","guide.prompt6":"Create a prefab named Enemy with Sprite and BoxCollider2D components","guide.tips_title":"💡 Tips","guide.tip1":"Select a node first, then describe the action — AI will target the selected object","guide.tip2":"AI auto-retries on errors, no manual intervention needed","guide.tip3":"Describe batch operations in one sentence — AI will use batch mode automatically","guide.tip4":"All operations are local (127.0.0.1 only), nothing is exposed to the internet","badge.community":"Community","badge.pro":"Pro","badge.enterprise":"Enterprise","license.community_edition":"Community Edition","license.pro_edition":"Pro Edition","license.enterprise_edition":"Enterprise Edition","license.free":"Free","license.activated":"Activated","license.expired":"Expired","license.not_activated":"Not Activated","license.expiry_prefix":"Valid until","footer.sync":"🔄 Sync","update.available":"🎉 Update Available","update.current":"Current","update.latest":"Latest","update.changelog":"What's New","update.download":"Download","update.downloading":"Downloading","update.verifying":"Verifying...","update.install":"Install & Restart","update.installing":"Installing...","update.done":"✅ Update complete. Restart Cocos Creator to apply.","update.error":"Update Failed","update.retry":"Retry","update.notify":"Update","update.breaking":"⚠ Breaking change — backup your project before upgrading","update.up_to_date":"Already up to date"}});var f="aura-for-cocos",de="1.0.14";var j=null;module.exports=Editor.Panel.define({template:`

    <div class="mcp-panel" id="app">

      <!-- Brand Line -->
      <div class="brand-line"></div>

      <!-- Header -->
      <div class="panel-header">
        <div class="logo-icon"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAABqklEQVRIie2UPU/CQADH/3ctFBQSE4cujm5u+gUcnfwEji5+AhcXFxc/gYuLi5OJiYmDg4ODMTExMRoTE6MxGl9iKFB67V17vBTjwE1N7v+7/+/u2gP+e6j+DZcAqAAUgCIiLYBuALqIaI8A9wC4BcBtAN4A8AaANwC8AeANAG8AeAPAGwDeAPAGgDcAvAHgDQBvAHgDwBsA3gDwBoA3ALwB4A0AbwB4A8AbAN4A8AaANwC8AeANAG8AeAPAGwDeAPAGgDcAvAHgDQBvAHgDwBsA3gDwBoA3ALwB4A0AbwB4A8AbAN4A8AaAN/4A8AaANwC8AeANAG8AeAPAGwDeAPAGgDcAvAHgDQBvAHgDwBsA3gDwBoA3ALwB4A0AbwB4A8AbAN4A8AaANwC8AeANAG8AeAPAGwDeAPAGgDcAvAHgDQBvAHgDwBsA3gDwBoA3ALwB4A0AbwB4A8AbAN4A8AaANwC8AeANAG/8AeANAG8AeAPAGwDeAPAGgDcAvAHgDQBvAHgDwBsA3gDwBoA3ALwB4A0AbwB4A8AbAN4A8AaAN/6/8Q3SaGv8FjMJHwAAAABJRU5ErkJggg==" /></div>
        <span class="brand-txt">Aura</span>
        <div class="holo-badge" id="holoBadge"><div class="holo-badge-inner" data-i18n="badge.community">Community</div></div>
        <div class="header-actions">
          <button id="updateBtn" class="ghost-btn update-notify-btn" style="display:none;" data-i18n="update.notify">有更新</button>
          <button id="langBtn" class="ghost-btn">中/EN</button>
          <button id="refreshBtn" class="ghost-btn" data-i18n="footer.sync">Sync</button>
        </div>
      </div>

      <!-- Tab Navigation -->
      <div class="mcp-tabs-header">
        <div class="mcp-tab active" data-target="tabStatus" data-i18n="tab.status">状态</div>
        <div class="mcp-tab" data-target="tabControl" data-i18n="tab.control">控制</div>
        <div class="mcp-tab" data-target="tabConfig" data-i18n="tab.config">互联</div>
        <div class="mcp-tab" data-target="tabSettings" data-i18n="tab.settings">设置</div>
        <div class="mcp-tab" data-target="tabGuide" data-i18n="tab.guide">指南</div>
      </div>

      <!-- Tab Content -->
      <div class="mcp-tabs-container">

          <!-- 1. Status Tab -->
          <div class="mcp-tab-content active" id="tabStatus">

            <div class="status-bar" id="statusBanner">
              <div id="statusDot" class="status-dot offline"></div>
              <span id="statusText" class="status-lbl status-text offline">Offline</span>
              <span id="endpointValue" class="status-port"></span>
            </div>

            <div id="updateBanner" class="update-banner" style="display:none;"></div>

            <div class="stats-list" id="bentoGrid">
              <div class="stat-row">
                <span class="stat-label" data-i18n="status.tools">TOOLS</span>
                <span class="stat-value" id="toolCount">-</span>
              </div>
              <div class="stat-row">
                <span class="stat-label" data-i18n="status.actions">ACTIONS</span>
                <span class="stat-value" id="totalActionCount">-</span>
              </div>
              <div class="stat-row">
                <span class="stat-label" data-i18n="status.clients">CLIENTS</span>
                <span class="stat-value" id="connectionCount">-</span>
              </div>
              <div class="stat-row">
                <span class="stat-label" data-i18n="status.port">PORT</span>
                <span class="stat-value" id="portValue">-</span>
              </div>
            </div>

            <div class="project-card">
              <div class="proj-header">
                <div class="proj-name" id="projectName">-</div>
                <span class="proj-ver" id="editorVersion">-</span>
              </div>
              <div class="proj-details">
                <div class="proj-row">
                  <span class="proj-key">Path</span>
                  <span class="proj-val" id="projectPath">-</span>
                </div>
                <div class="proj-row">
                  <span class="proj-key">Uptime</span>
                  <span class="proj-val proj-uptime" id="uptime">-</span>
                </div>
              </div>
            </div>

            <div class="empty-state" id="emptyState" style="display:none;">
              <div class="empty-state-icon">⏸</div>
              <div class="empty-state-text">服务未启动<br><span style="font-size:11px;opacity:0.5;">请前往「控制」Tab 启动 Aura 服务</span></div>
            </div>

          </div>

          <!-- 2. Control Tab -->
          <div class="mcp-tab-content flex-column" id="tabControl">
            <div class="control-header">
              <h3 data-i18n="ctrl.title">服务管理</h3>
              <p>当前服务状态：<span id="ctrlStatusLabel" style="color:#f14c4c;font-weight:600;">已停止</span></p>
            </div>
            <div class="button-grid">
              <button id="startBtn" class="btn btn-success" data-i18n="ctrl.start">▶ 启动服务</button>
              <button id="stopBtn" class="btn btn-danger" data-i18n="ctrl.stop">■ 停止服务</button>
            </div>
            <button id="restartBtn" class="btn btn-holo-btn full-width" data-i18n="ctrl.restart">↻ 重启服务</button>

            <div class="divider"></div>

            <div class="control-header">
              <h3 data-i18n="ctrl.tools_title">工具模块配置</h3>
              <p data-i18n="ctrl.tools_desc">关闭的工具 AI 将完全无法感知，实时生效。</p>
            </div>
            <div id="toolToggleList" class="tool-toggle-list"></div>
          </div>

          <!-- 3. IDE Config Tab -->
          <div class="mcp-tab-content flex-column" id="tabConfig">
            <div class="control-header">
              <h3 data-i18n="cfg.title">IDE 互联配置</h3>
              <p data-i18n="cfg.desc">一键将 Cocos 环境注入至主流 AI 编程助手。</p>
            </div>
            <div class="ide-status-list">
              <div class="ide-card" id="ideCursor">
                <div class="ide-info"><span class="ide-title">Cursor</span><span class="ide-status" id="statusCursor">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="cursor">注入配置</button>
              </div>
              <div class="ide-card" id="ideWindsurf">
                <div class="ide-info"><span class="ide-title">Windsurf</span><span class="ide-status" id="statusWindsurf">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="windsurf">注入配置</button>
              </div>
              <div class="ide-card" id="ideClaude">
                <div class="ide-info"><span class="ide-title">Claude Desktop</span><span class="ide-status" id="statusClaude">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="claude">注入配置</button>
              </div>
              <div class="ide-card" id="ideTrae">
                <div class="ide-info"><span class="ide-title">Trae</span><span class="ide-status" id="statusTrae">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="trae">注入配置</button>
              </div>
              <div class="ide-card" id="ideKiro">
                <div class="ide-info"><span class="ide-title">Kiro AI IDE</span><span class="ide-status" id="statusKiro">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="kiro">注入配置</button>
              </div>
              <div class="ide-card" id="ideAntigravity">
                <div class="ide-info"><span class="ide-title">Antigravity</span><span class="ide-status" id="statusAntigravity">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="antigravity">注入配置</button>
              </div>
              <div class="ide-card" id="ideGeminiCli">
                <div class="ide-info"><span class="ide-title">Gemini CLI</span><span class="ide-status" id="statusGeminiCli">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="gemini-cli">注入配置</button>
              </div>
              <div class="ide-card" id="ideCodex">
                <div class="ide-info"><span class="ide-title">OpenAI Codex</span><span class="ide-status" id="statusCodex">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="codex">注入配置</button>
              </div>
              <div class="ide-card" id="ideClaudeCode">
                <div class="ide-info"><span class="ide-title">Claude Code</span><span class="ide-status" id="statusClaudeCode">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="claude-code">注入配置</button>
              </div>
              <div class="ide-card" id="ideCodebuddy">
                <div class="ide-info"><span class="ide-title">CodeBuddy (腾讯)</span><span class="ide-status" id="statusCodebuddy">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="codebuddy">注入配置</button>
              </div>
              <div class="ide-card" id="ideComate">
                <div class="ide-info"><span class="ide-title">Comate (百度)</span><span class="ide-status" id="statusComate">检测中...</span></div>
                <button class="btn config-ide-btn" data-ide="comate">注入配置</button>
              </div>
            </div>
            <div class="config-result" id="configResult" style="display:none;">
              <span id="configIcon"></span>
              <span id="configMessage"></span>
            </div>
            <div class="info-box">
              本操作将当前端点写入 IDE 的 MCP 配置文件，您需要在目标 IDE 中刷新或重启生效。
            </div>
          </div>

          <!-- 4. Settings Tab -->
          <div class="mcp-tab-content flex-column" id="tabSettings">
            <div class="control-header">
              <h3 data-i18n="settings.license_title">License 授权</h3>
              <p data-i18n="settings.license_desc">管理 Pro 版 License Key 激活状态。</p>
            </div>
            <div class="license-card" id="licenseCard">
              <div class="license-status" id="licenseStatusSection">
                <div class="license-badge" id="licenseBadge">
                  <span class="license-edition" id="licenseEdition">Community</span>
                  <span class="license-state community" id="licenseState">免费版</span>
                </div>
                <div class="license-detail" id="licenseDetail" style="display:none;">
                  <span class="license-expiry" id="licenseExpiry"></span>
                  <span class="license-owner" id="licenseOwner"></span>
                </div>
                <div class="license-error" id="licenseError" style="display:none;"></div>
              </div>
              <div class="license-input-row">
                <input type="text" id="licenseKeyInput" class="license-input" placeholder="COCOS-PRO-XXXXXXXX-XXXXXXXX-XXXXXXXX" spellcheck="false" autocomplete="off" />
                <button id="activateLicenseBtn" class="btn btn-primary btn-activate" data-i18n="settings.activate">激活</button>
              </div>
              <div class="license-hint" data-i18n="settings.license_hint">输入 License Key 后点击激活，需要重启插件使 Pro 工具生效。</div>
            </div>

            <div class="divider"></div>

            <div class="control-header">
              <h3 data-i18n="settings.title">安全与性能</h3>
              <p data-i18n="settings.desc">配置 MCP Bridge 的安全策略和性能参数。</p>
            </div>
            <div class="settings-card">
              <div class="setting-item">
                <div class="setting-info">
                  <span class="setting-label" data-i18n="settings.rate_limit">Rate Limit (req/min)</span>
                  <span class="setting-hint" data-i18n="settings.rate_limit_hint">每分钟允许的最大请求数 (10-10000)</span>
                </div>
                <input type="number" id="settingRateLimit" class="setting-input" min="10" max="10000" step="10" value="240" />
              </div>
              <div class="setting-item">
                <div class="setting-info">
                  <span class="setting-label" data-i18n="settings.loopback">Localhost Restrict</span>
                  <span class="setting-hint" data-i18n="settings.loopback_hint">开启时仅允许 127.0.0.1 访问</span>
                </div>
                <input type="checkbox" id="settingLoopback" class="tool-toggle" checked />
              </div>
              <div class="setting-warn" id="loopbackWarn" style="display:none;" data-i18n="settings.warn_loopback">⚠ 警告: 关闭回环限制将允许外部网段访问，请确保网络安全。</div>
              <div class="setting-item">
                <div class="setting-info">
                  <span class="setting-label" data-i18n="settings.body_limit">Max Payload Size</span>
                  <span class="setting-hint" data-i18n="settings.body_limit_hint">单次请求/返回的最大数据体积</span>
                </div>
                <select id="settingBodyLimit" class="setting-select">
                  <option value="65536">64 KB</option>
                  <option value="262144">256 KB</option>
                  <option value="524288">512 KB</option>
                  <option value="1048576" selected>1 MB</option>
                  <option value="2097152">2 MB</option>
                  <option value="5242880">5 MB</option>
                  <option value="10485760">10 MB</option>
                  <option value="52428800">50 MB</option>
                </select>
              </div>
              <div class="setting-item">
                <div class="setting-info">
                  <span class="setting-label" data-i18n="settings.rollback">自动回滚</span>
                  <span class="setting-hint" data-i18n="settings.rollback_hint">复杂原子操作失败时自动恢复场景</span>
                </div>
                <input type="checkbox" id="settingRollback" class="tool-toggle" checked />
              </div>
            </div>
            <div class="button-grid" style="margin-top:12px;">
              <button id="saveSettingsBtn" class="btn btn-primary" data-i18n="settings.save">保存配置</button>
              <button id="resetSettingsBtn" class="btn" data-i18n="settings.reset">恢复默认</button>
            </div>
            <div class="config-result" id="settingsResult" style="display:none;">
              <span id="settingsIcon"></span>
              <span id="settingsMessage"></span>
            </div>
          </div>

          <!-- 5. Guide Tab -->
          <div class="mcp-tab-content flex-column" id="tabGuide">
            <div class="control-header">
              <h3 data-i18n="guide.title">交互指南</h3>
              <p data-i18n="guide.desc">建议使用如下对话模式驱动引擎工作。</p>
            </div>
            <div class="guide-steps">
              <div class="guide-step">
                <div class="step-number">1</div>
                <div class="step-content">
                  <div class="step-title" data-i18n="guide.step1_title">确认服务连通性</div>
                  <div class="step-desc" data-i18n="guide.step1_desc">在 IDE 中检查 MCP Status，或提问 &quot;请测试一下 Cocos 桥接状态&quot;。</div>
                </div>
              </div>
              <div class="guide-step">
                <div class="step-number">2</div>
                <div class="step-content">
                  <div class="step-title" data-i18n="guide.step2_title">选定操作目标</div>
                  <div class="step-desc" data-i18n="guide.step2_desc">若要修改现有节点，请先在层级树选中，再对 AI 说 &quot;把当前选中的节点...&quot;。</div>
                </div>
              </div>
              <div class="guide-step">
                <div class="step-number">3</div>
                <div class="step-content">
                  <div class="step-title" data-i18n="guide.step3_title">检查执行结果</div>
                  <div class="step-desc" data-i18n="guide.step3_desc">AI 拥有读写双向能力，修改后编辑器内实时刷新，效果不对可说 &quot;撤销刚才的修改&quot;。</div>
                </div>
              </div>
            </div>
            <div class="divider"></div>
            <div class="control-header">
              <h3 data-i18n="guide.examples_title">示例提示词</h3>
            </div>
            <div class="prompt-list">
              <button class="prompt-card">
                <span class="prompt-tag" data-i18n="guide.tag_scene">场景查询</span>
                <div class="prompt-text" data-i18n="guide.prompt1">帮我分析当前场景的根节点结构，列出所有 Canvas 下的子节点。</div>
                <div class="prompt-copy" title="复制">⎘</div>
              </button>
              <button class="prompt-card">
                <span class="prompt-tag" data-i18n="guide.tag_create">实例创建</span>
                <div class="prompt-text" data-i18n="guide.prompt2">在当前选中的节点下，创建一个名为 &quot;LoginButton&quot; 的按钮，并添加 Widget 居中。</div>
                <div class="prompt-copy" title="复制">⎘</div>
              </button>
            </div>
            <div class="info-box guide-tips">
              <div class="tips-title" data-i18n="guide.tips_title">开发建议</div>
              <ul class="tips-list">
                <li data-i18n="guide.tip1">尽量遵循单指令单操作，避免一条对话发布多个复杂引擎改动。</li>
                <li data-i18n="guide.tip2">若 AI 提示组件未导入，请先确保项目中已存在继承自 cc.Component 的脚本。</li>
              </ul>
            </div>
          </div>

        </div><!-- /mcp-tabs-container -->

      <!-- Footer -->
      <div class="mcp-footer">
        <span class="footer-text">v<span id="versionText"></span></span>
      </div>

    </div>

  `,style:`

    html, body { background: #18181b !important; margin: 0; padding: 0; }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :host { background: #18181b; display: block; height: 100%; }

    .mcp-panel {
      color: #d4d4d8;
      font-size: 13px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', sans-serif;
      height: 100%; display: flex; flex-direction: column;
      background: linear-gradient(180deg, #18181b 0%, #161618 100%);
      user-select: none; position: relative; overflow: hidden;
    }

    /* ===== BRAND LINE (tooling accent — sky → teal, not “AI purple”) ===== */
    .brand-line {
      height: 2px; width: 100%; flex-shrink: 0;
      background: linear-gradient(90deg, #0ea5e9 0%, #14b8a6 55%, #0d9488 100%);
    }

    /* ===== HEADER ===== */
    .panel-header {
      display: flex; align-items: center; padding: 10px 16px; gap: 8px;
      background: rgba(24, 24, 27, 0.92);
      border-bottom: 1px solid #27272a;
      flex-shrink: 0;
    }
    .logo-icon {
      width: 22px; height: 22px; flex-shrink: 0; border-radius: 5px; overflow: hidden;
    }
    .logo-icon img { width: 100%; height: 100%; display: block; }
    .brand-txt { font-size: 14px; font-weight: 600; color: #f4f4f5; letter-spacing: -0.02em; }
    .holo-badge {
      display: inline-block; font-size: 10px; font-weight: 600; letter-spacing: 0.5px;
    }
    .holo-badge-inner {
      display: inline-block;
      background: #27272a; color: #7dd3fc;
      padding: 2px 8px; border-radius: 3px;
      font-size: 10px; border: 1px solid rgba(14,165,233,0.28);
    }
    .header-actions {
      margin-left: auto; display: flex; gap: 4px;
    }
    .ghost-btn {
      background: transparent; border: none; font-size: 11px; font-family: inherit;
      color: #858585; cursor: pointer; padding: 4px 8px; border-radius: 3px;
      transition: color 0.15s, background 0.15s;
    }
    .ghost-btn:hover { color: #cccccc; background: rgba(255,255,255,0.06); }
    .ghost-btn.spinning { animation: refreshSpin 0.6s ease-in-out; }

    /* ===== TAB NAVIGATION ===== */
    .mcp-tabs-header {
      display: flex; background: rgba(24, 24, 27, 0.85);
      border-bottom: 1px solid #27272a;
      flex-shrink: 0; padding: 0 12px; gap: 0;
    }
    .mcp-tab {
      padding: 8px 14px; cursor: pointer;
      font-size: 12px; font-weight: 500; color: #71717a;
      border-bottom: 2px solid transparent;
      transition: color 0.15s, border-color 0.15s;
    }
    .mcp-tab:hover { color: #d4d4d8; }
    .mcp-tab.active {
      color: #fafafa;
      border-bottom-color: #0ea5e9;
    }

    /* ===== CONTENT AREA ===== */
    .mcp-tabs-container {
      flex: 1; padding: 16px; overflow-y: auto;
    }
    .mcp-tabs-container::-webkit-scrollbar { width: 6px; }
    .mcp-tabs-container::-webkit-scrollbar-thumb { background: #3f3f46; border-radius: 3px; }
    .mcp-tabs-container::-webkit-scrollbar-track { background: transparent; }

    .mcp-tab-content { display: none; flex-direction: column; gap: 14px; }
    .mcp-tab-content.active { display: flex; animation: fadeIn 0.15s ease both; }
    .mcp-tab-content.flex-column { flex-direction: column; }
    .mcp-tab-content.flex-column.active { display: flex; }

    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

    /* ===== FOOTER ===== */
    .mcp-footer {
      display: flex; align-items: center; justify-content: center;
      padding: 6px 16px; border-top: 1px solid #27272a; flex-shrink: 0;
    }
    .footer-text {
      font-size: 10px; color: #555;
      font-family: 'SF Mono', Consolas, 'Courier New', monospace;
    }

    /* ===== STATUS BAR ===== */
    .status-bar {
      display: flex; align-items: center; gap: 10px; padding: 10px 14px;
      border-radius: 6px;
      background: #27272a; border: 1px solid #3f3f46;
    }
    .status-dot {
      display: inline-block; width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0;
    }
    .status-dot.online { background: #5eead4; }
    .status-dot.offline { background: #f14c4c; }
    .status-lbl { font-size: 12.5px; font-weight: 500; }
    .status-text.online { color: #5eead4; font-weight: 600; }
    .status-text.offline { color: #f14c4c; }
    .status-port {
      margin-left: auto;
      font-family: 'SF Mono', Consolas, 'Courier New', monospace;
      font-size: 11px; color: #858585;
    }

    /* ===== STATS LIST ===== */
    .stats-list {
      background: #27272a; border: 1px solid #3f3f46; border-radius: 6px;
      padding: 4px 0;
    }
    .stat-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 7px 14px;
    }
    .stat-row + .stat-row { border-top: 1px solid #27272a; }
    .stat-label {
      font-size: 11px; text-transform: uppercase; letter-spacing: 1px;
      color: #858585; font-weight: 600;
    }
    .stat-value {
      font-family: 'SF Mono', Consolas, 'Courier New', monospace;
      font-size: 14px; font-weight: 600; color: #e0e0e0;
    }
    .value-changed { animation: valueFlash 0.5s ease-out; }
    @keyframes valueFlash {
      0% { color: #38bdf8; }
      100% { color: #e4e4e7; }
    }

    /* ===== PROJECT CARD ===== */
    .project-card {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 6px; padding: 12px 14px;
    }
    .proj-header {
      display: flex; align-items: center; gap: 8px; margin-bottom: 8px;
    }
    .proj-name {
      font-size: 14px; font-weight: 600; color: #e0e0e0;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .proj-ver {
      font-family: 'SF Mono', Consolas, 'Courier New', monospace; font-size: 10px;
      padding: 2px 7px; border-radius: 3px; flex-shrink: 0;
      background: #3f3f46; border: 1px solid #52525b; color: #a1a1aa;
    }
    .proj-details { display: flex; flex-direction: column; gap: 4px; }
    .proj-row { display: flex; align-items: center; gap: 8px; min-width: 0; }
    .proj-key {
      font-size: 10px; font-weight: 600; color: #858585;
      text-transform: uppercase; letter-spacing: 0.5px; flex-shrink: 0; width: 42px;
    }
    .proj-val {
      font-family: 'SF Mono', Consolas, 'Courier New', monospace; font-size: 11px;
      color: #999;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .proj-uptime { color: #5eead4; }

    /* ===== SECTION HEADERS ===== */
    .control-header { display: flex; flex-direction: column; gap: 4px; }
    .control-header h3 {
      font-size: 13px; font-weight: 600; color: #e0e0e0; margin: 0;
    }
    .control-header p { color: #858585; font-size: 12px; line-height: 1.5; margin: 0; }

    .divider { height: 1px; background: #3f3f46; }

    /* ===== BUTTONS ===== */
    .btn {
      border: 1px solid #3f3f46; border-radius: 6px;
      padding: 8px 12px; font-size: 12px; font-weight: 500;
      color: #cccccc; background: transparent;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      gap: 6px; transition: background 0.15s, border-color 0.15s, color 0.15s;
      font-family: inherit;
    }
    .btn:hover { background: #3f3f46; border-color: #52525b; color: #f4f4f5; }
    .btn:active { background: #333; }
    .btn-primary { background: #0ea5e9; color: #fff; border-color: #0ea5e9; font-weight: 600; }
    .btn-primary:hover { background: #0284c7; border-color: #0284c7; color: #fff; }
    .btn-success { background: rgba(94,234,212,0.12); color: #5eead4; border-color: rgba(94,234,212,0.3); }
    .btn-success:hover { background: rgba(94,234,212,0.2); border-color: rgba(94,234,212,0.5); }
    .btn-danger { background: rgba(241,76,76,0.12); color: #f14c4c; border-color: rgba(241,76,76,0.3); }
    .btn-danger:hover { background: rgba(241,76,76,0.2); border-color: rgba(241,76,76,0.5); }
    .btn-holo-btn {
      background: rgba(14,165,233,0.1); color: #7dd3fc;
      border: 1px solid rgba(14,165,233,0.32);
    }
    .btn-holo-btn:hover {
      background: rgba(14,165,233,0.18); border-color: rgba(14,165,233,0.45); color: #bae6fd;
    }
    .btn-disabled { opacity: 0.35; pointer-events: none; }
    .button-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .full-width { width: 100%; }

    /* ===== IDE CARDS ===== */
    .ide-status-list { display: flex; flex-direction: column; gap: 6px; }
    .ide-card {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; padding: 9px 14px;
      display: flex; align-items: center; justify-content: space-between;
      transition: border-color 0.15s;
    }
    .ide-card:hover { border-color: #555; }
    .ide-info { display: flex; align-items: center; gap: 10px; }
    .ide-title { font-size: 12px; font-weight: 500; color: #cccccc; }
    .ide-status { font-size: 11px; color: #858585; }
    .ide-status.ready {
      color: #5eead4; background: rgba(94,234,212,0.1);
      border: 1px solid rgba(94,234,212,0.25); padding: 2px 8px; border-radius: 3px;
    }
    .ide-status.unready { color: #858585; }
    .config-ide-btn { padding: 5px 10px !important; font-size: 11px !important; }

    /* ===== TOGGLE SWITCH ===== */
    .tool-toggle {
      appearance: none; -webkit-appearance: none; width: 36px; height: 20px; flex-shrink: 0;
      background: #3f3f46; border: 1px solid #555;
      border-radius: 20px; position: relative; cursor: pointer; transition: 0.2s;
    }
    .tool-toggle::after {
      content: ''; position: absolute; top: 2px; left: 2px; width: 14px; height: 14px;
      background: #858585; border-radius: 50%; transition: 0.2s;
    }
    .tool-toggle:checked {
      background: #0ea5e9; border-color: #0ea5e9;
    }
    .tool-toggle:checked::after { transform: translateX(16px); background: #fff; }
    .tool-toggle:disabled { opacity: 0.4; cursor: not-allowed; }

    /* ===== FORM INPUTS ===== */
    .setting-input, .setting-select, .license-input {
      background: #3f3f46; border: 1px solid #555;
      border-radius: 3px; color: #cccccc;
      font-family: 'SF Mono', Consolas, 'Courier New', monospace;
      font-size: 12px; padding: 5px 8px; outline: none; transition: border-color 0.15s;
    }
    .setting-input { width: 84px; height: 28px; text-align: right; }
    .setting-select { height: 28px; cursor: pointer; }
    .setting-input:focus, .setting-select:focus, .license-input:focus {
      border-color: #0ea5e9;
    }
    .license-input { flex: 1; height: 32px; padding: 0 10px; font-size: 11px; letter-spacing: 0.5px; }
    .license-input::placeholder { color: #555; }

    /* ===== SETTING ITEMS ===== */
    .setting-item { display: flex; align-items: center; justify-content: space-between; min-height: 36px; gap: 12px; }
    .setting-info { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
    .setting-label { font-size: 12px; font-weight: 500; color: #cccccc; }
    .setting-hint { font-size: 11px; color: #858585; line-height: 1.4; }
    .settings-card {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; padding: 14px; display: flex; flex-direction: column; gap: 12px;
    }
    .setting-warn {
      font-size: 11px; color: #f14c4c; background: rgba(241,76,76,0.08);
      border: 1px solid rgba(241,76,76,0.25); border-radius: 3px; padding: 8px 12px;
    }

    /* ===== TOOL TOGGLES ===== */
    .tool-toggle-list { display: flex; flex-direction: column; gap: 5px; }
    .tool-wrapper { display: flex; flex-direction: column; }
    .tool-row {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; padding: 9px 14px;
      display: flex; align-items: center; justify-content: space-between;
      border-left: 2px solid transparent; transition: border-color 0.15s, background 0.15s;
    }
    .tool-row:hover { border-color: #52525b; border-left-color: #52525b; background: #2a2a2e; }
    .tool-row.expanded { border-left-color: #0ea5e9; background: #27272a; }
    .tool-info { display: flex; flex-direction: column; gap: 3px; flex: 1; }
    .tool-name-row { display: flex; align-items: center; gap: 8px; }
    .tool-name { font-size: 12px; font-weight: 500; color: #cccccc; font-family: 'SF Mono', Consolas, 'Courier New', monospace; }
    .tool-desc { font-size: 11px; color: #858585; }
    .action-count-badge, .core-badge {
      display: inline-flex; align-items: center;
      padding: 1px 6px; border-radius: 3px; border: 1px solid #3f3f46;
      font-size: 10px; color: #a1a1aa; background: #3f3f46;
    }
    .pro-badge {
      display: inline-flex; align-items: center;
      padding: 1px 6px; border-radius: 3px;
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      background: #b45309; color: #fffbeb; border: 1px solid rgba(245,158,11,0.45);
    }
    .pro-extra-badge {
      display: inline-flex; align-items: center;
      padding: 1px 6px; border-radius: 3px; font-size: 9px; font-weight: 600;
      background: rgba(245,158,11,0.1); color: #fcd34d; border: 1px solid rgba(245,158,11,0.32);
    }
    .pro-lock-icon { font-size: 14px; opacity: 0.5; flex-shrink: 0; }
    .pro-locked { opacity: 0.45; }
    .pro-locked:hover { opacity: 0.6; }
    .pro-locked-text { color: #555 !important; }

    /* ===== ACTION PANEL ===== */
    .action-panel {
      background: #18181b; border: 1px solid #3f3f46;
      border-top: none; border-radius: 0 0 4px 4px;
      max-height: 0; opacity: 0; padding: 0 12px;
      transition: max-height 0.25s ease, opacity 0.2s ease, padding 0.25s ease;
      overflow: hidden;
    }
    .action-panel.open { max-height: 300px; opacity: 1; padding: 10px 12px; }
    .action-grid { display: flex; flex-wrap: wrap; gap: 4px; }
    .action-chip {
      padding: 2px 7px; border-radius: 3px; background: #3f3f46;
      border: 1px solid #3f3f46; font-size: 10px;
      font-family: 'SF Mono', Consolas, 'Courier New', monospace; color: #999;
    }
    .action-chip-pro { opacity: 0.5; border-style: dashed !important; }
    .action-chip-locked { opacity: 0.3; border-style: dashed !important; color: #555 !important; }

    /* ===== GUIDE STEPS ===== */
    .guide-steps { display: flex; flex-direction: column; gap: 8px; }
    .guide-step {
      display: flex; gap: 12px; padding: 12px 14px;
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; align-items: flex-start;
    }
    .step-number {
      width: 24px; height: 24px; border-radius: 50%; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 700; color: #38bdf8;
      background: rgba(14,165,233,0.12); border: 1px solid rgba(14,165,233,0.28);
    }
    .step-content { display: flex; flex-direction: column; gap: 4px; flex: 1; }
    .step-title { font-size: 13px; font-weight: 600; color: #e0e0e0; }
    .step-desc { font-size: 12px; color: #858585; line-height: 1.5; }

    .prompt-list { display: flex; flex-direction: column; gap: 6px; }
    .prompt-card {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; padding: 10px 12px;
      display: flex; align-items: flex-start; gap: 10px; cursor: pointer;
      text-align: left; transition: border-color 0.15s; font-family: inherit;
    }
    .prompt-card:hover { border-color: #555; }
    .prompt-tag {
      font-size: 10px; font-weight: 600; letter-spacing: 0.5px; flex-shrink: 0;
      padding: 3px 7px; border-radius: 3px;
      background: rgba(14,165,233,0.1); border: 1px solid rgba(14,165,233,0.28); color: #7dd3fc;
    }
    .prompt-text { font-size: 12px; color: #999; line-height: 1.5; flex: 1; }
    .prompt-copy {
      color: #555; font-size: 13px; cursor: pointer;
      padding: 2px 5px; transition: color 0.15s; background: none; border: none;
    }
    .prompt-copy:hover, .prompt-copy.copied { color: #5eead4; }
    .guide-tips .tips-title { font-size: 12px; font-weight: 600; color: #cccccc; margin-bottom: 8px; }
    .tips-list { margin: 0; padding-left: 18px; list-style: disc; }
    .tips-list li { font-size: 11px; color: #858585; margin-bottom: 4px; line-height: 1.5; }

    /* ===== INFO / RESULT BOXES ===== */
    .info-box {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; padding: 11px 14px;
      font-size: 11px; color: #858585; line-height: 1.6;
    }
    .config-result {
      display: flex; align-items: center; gap: 8px; padding: 9px 12px;
      border-radius: 4px; font-size: 12px;
      border: 1px solid #3f3f46; background: #27272a;
    }
    .config-result.success { background: rgba(94,234,212,0.08); border-color: rgba(94,234,212,0.25); color: #5eead4; }
    .config-result.error { background: rgba(241,76,76,0.08); border-color: rgba(241,76,76,0.25); color: #f14c4c; }

    /* ===== LICENSE CARD ===== */
    .license-card {
      background: #27272a; border: 1px solid #3f3f46;
      border-radius: 4px; padding: 14px; display: flex; flex-direction: column; gap: 12px;
    }
    .license-badge { display: flex; align-items: center; gap: 8px; }
    .license-edition { font-size: 14px; font-weight: 600; color: #e0e0e0; font-family: 'SF Mono', Consolas, 'Courier New', monospace; }
    .license-state { padding: 3px 8px; border-radius: 3px; font-size: 11px; font-weight: 500; }
    .license-state.community { border: 1px solid #3f3f46; color: #858585; }
    .license-state.active { border: 1px solid rgba(94,234,212,0.35); color: #5eead4; background: rgba(94,234,212,0.08); }
    .license-state.expired { border: 1px solid rgba(241,76,76,0.35); color: #f14c4c; background: rgba(241,76,76,0.08); }
    .license-state.no-key { border: 1px solid rgba(14,165,233,0.35); color: #7dd3fc; background: rgba(14,165,233,0.08); }
    .license-detail { font-size: 12px; color: #858585; display: flex; gap: 12px; }
    .license-error { font-size: 12px; color: #f14c4c; }
    .license-input-row { display: flex; gap: 8px; }
    .btn-activate { flex-shrink: 0; min-width: 58px; height: 32px; padding: 0 12px; }
    .license-hint { font-size: 11px; color: #555; line-height: 1.4; }

    /* ===== EMPTY STATE ===== */
    .empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 28px 16px; gap: 12px; }
    .empty-state-icon { font-size: 32px; opacity: 0.3; }
    .empty-state-text { font-size: 13px; color: #858585; text-align: center; line-height: 1.6; }

    /* ===== STOP CONFIRM ===== */
    .btn-danger.confirming { animation: confirmPulse 0.8s infinite; }
    @keyframes confirmPulse {
      0%,100% { box-shadow: 0 0 0 0 rgba(241,76,76,0.4); }
      50% { box-shadow: 0 0 0 4px rgba(241,76,76,0); }
    }

    /* ===== COPYABLE ===== */
    .copyable { cursor: pointer; position: relative; }
    .copyable:hover { opacity: 0.75; }
    .copy-toast {
      position: absolute; top: -22px; left: 50%; transform: translateX(-50%);
      background: #5eead4; color: #000; font-size: 10px; padding: 2px 8px; border-radius: 3px;
      white-space: nowrap; pointer-events: none; animation: toastFade 1s ease forwards;
    }
    @keyframes toastFade {
      0% { opacity: 1; transform: translateX(-50%) translateY(0); }
      100% { opacity: 0; transform: translateX(-50%) translateY(-8px); }
    }

    /* ===== INJECT BUTTON FEEDBACK ===== */
    .config-ide-btn.inject-success { background: rgba(94,234,212,0.12) !important; border-color: rgba(94,234,212,0.3) !important; color: #5eead4 !important; }
    .config-ide-btn.inject-fail { background: rgba(241,76,76,0.12) !important; border-color: rgba(241,76,76,0.3) !important; color: #f14c4c !important; }

    /* ===== REFRESH SPIN ===== */
    @keyframes refreshSpin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

    /* ===== SKELETON LOADER ===== */
    .stats-list.loading .stat-value {
      background: linear-gradient(90deg, #27272a 25%, #3f3f46 50%, #27272a 75%);
      background-size: 200% 100%;
      animation: skeletonShimmer 1.5s ease-in-out infinite;
      color: transparent !important; border-radius: 3px;
      min-width: 40px; display: inline-block;
    }
    @keyframes skeletonShimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }

    /* ===== UPDATE BANNER ===== */
    .update-banner {
      border-radius: 6px; padding: 12px 14px;
      background: rgba(14,165,233,0.08); border: 1px solid rgba(14,165,233,0.28);
      display: flex; flex-direction: column; gap: 10px;
    }
    .update-header { display: flex; align-items: center; justify-content: space-between; }
    .update-title { font-size: 13px; font-weight: 600; color: #7dd3fc; }
    .update-ver-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .update-ver-label { font-size: 11px; color: #858585; }
    .update-ver-value {
      font-family: 'SF Mono', Consolas, 'Courier New', monospace;
      font-size: 11px; color: #bae6fd; font-weight: 600;
    }
    .update-arrow { font-size: 12px; color: #858585; }
    .update-changelog {
      font-size: 11px; color: #999; line-height: 1.5;
      background: rgba(0,0,0,0.2); border-radius: 3px;
      padding: 7px 10px; border-left: 2px solid rgba(14,165,233,0.4);
      max-height: 60px; overflow: hidden; text-overflow: ellipsis;
    }
    .update-breaking {
      font-size: 11px; color: #f59e0b;
      background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.25);
      border-radius: 3px; padding: 6px 10px;
    }
    .update-actions { display: flex; gap: 8px; align-items: center; }
    .update-progress-wrap {
      display: flex; flex-direction: column; gap: 5px;
    }
    .update-progress-bar {
      height: 4px; border-radius: 2px; background: #3f3f46; overflow: hidden;
    }
    .update-progress-fill {
      height: 100%; background: linear-gradient(90deg, #0ea5e9, #14b8a6); border-radius: 2px;
      transition: width 0.3s ease;
    }
    .update-progress-text { font-size: 11px; color: #858585; }
    .update-done-msg {
      font-size: 12px; color: #5eead4; font-weight: 500;
    }
    .update-error-msg { font-size: 12px; color: #f14c4c; }
    .update-notify-btn {
      color: #7dd3fc !important;
      border: 1px solid rgba(14,165,233,0.35) !important;
      background: rgba(14,165,233,0.1) !important;
      border-radius: 3px;
    }
    .update-notify-btn:hover { background: rgba(14,165,233,0.18) !important; }
    @keyframes updatePulse {
      0%,100% { opacity: 1; }
      50% { opacity: 0.6; }
    }
    .update-notify-btn { animation: updatePulse 2.5s ease-in-out infinite; }

  
  `,$:{app:"#app",bentoGrid:"#bentoGrid",holoBadge:"#holoBadge",statusDot:"#statusDot",statusText:"#statusText",portValue:"#portValue",endpointValue:"#endpointValue",projectName:"#projectName",projectPath:"#projectPath",editorVersion:"#editorVersion",toolCount:"#toolCount",connectionCount:"#connectionCount",totalActionCount:"#totalActionCount",uptime:"#uptime",emptyState:"#emptyState",ctrlStatusLabel:"#ctrlStatusLabel",startBtn:"#startBtn",stopBtn:"#stopBtn",restartBtn:"#restartBtn",statusCursor:"#statusCursor",statusWindsurf:"#statusWindsurf",statusClaude:"#statusClaude",statusTrae:"#statusTrae",statusKiro:"#statusKiro",statusAntigravity:"#statusAntigravity",statusGeminiCli:"#statusGeminiCli",statusCodex:"#statusCodex",statusClaudeCode:"#statusClaudeCode",statusCodebuddy:"#statusCodebuddy",statusComate:"#statusComate",configResult:"#configResult",configIcon:"#configIcon",configMessage:"#configMessage",versionText:"#versionText",refreshBtn:"#refreshBtn",langBtn:"#langBtn",toolToggleList:"#toolToggleList",settingRateLimit:"#settingRateLimit",settingLoopback:"#settingLoopback",settingBodyLimit:"#settingBodyLimit",settingRollback:"#settingRollback",loopbackWarn:"#loopbackWarn",saveSettingsBtn:"#saveSettingsBtn",resetSettingsBtn:"#resetSettingsBtn",settingsResult:"#settingsResult",settingsIcon:"#settingsIcon",settingsMessage:"#settingsMessage",licenseCard:"#licenseCard",licenseBadge:"#licenseBadge",licenseEdition:"#licenseEdition",licenseState:"#licenseState",licenseDetail:"#licenseDetail",licenseExpiry:"#licenseExpiry",licenseOwner:"#licenseOwner",licenseError:"#licenseError",licenseKeyInput:"#licenseKeyInput",activateLicenseBtn:"#activateLicenseBtn",updateBanner:"#updateBanner",updateBtn:"#updateBtn"},ready(){let e=this;e.$.versionText.textContent=de;let t={zh:te(),en:se()};e._I18N=t;let i="zh";try{i=localStorage.getItem("mcp-lang")||"zh"}catch{}e._currentLang=i;function l(s){i=s,e._currentLang=s;let o=t[s]||t.zh;e.$.app.querySelectorAll("[data-i18n]").forEach(a=>{let g=a.getAttribute("data-i18n");o[g]&&(a.textContent=o[g])}),e._lastLicenseStatus&&e.updateLicenseUI(e._lastLicenseStatus);try{localStorage.setItem("mcp-lang",s)}catch{}}l(i),e.$.langBtn.addEventListener("click",()=>{l(i==="zh"?"en":"zh")});let m=["bridge_status"],d={zh:{bridge_status:"桥接状态检测",scene_query:"场景只读查询",scene_operation:"场景写操作",asset_operation:"资产管理",editor_action:"编辑器操作",engine_action:"引擎全局操作",execute_script:"执行自定义脚本",register_custom_macro:"注册自定义宏",animation_tool:"动画管理",physics_tool:"物理组件管理",preferences:"编辑器偏好设置",broadcast:"编辑器事件广播",reference_image:"参考图叠加",tool_management:"工具可用性管理",setup_ui_layout:"一键 UI 布局",import_and_apply_texture:"导入并应用贴图",create_prefab_atomic:"一键创建预制体",auto_fit_physics_collider:"自动适配物理碰撞体",create_tween_animation_atomic:"一键创建动画",scene_generator:"AI 场景生成器",batch_engine:"批量操作引擎",scene_audit:"场景审计工具"},en:{bridge_status:"Bridge Status",scene_query:"Scene Read-Only Query",scene_operation:"Scene Write Operations",asset_operation:"Asset Management",editor_action:"Editor Actions",engine_action:"Engine Global Ops",execute_script:"Execute Custom Script",register_custom_macro:"Register Custom Macro",animation_tool:"Animation Management",physics_tool:"Physics Components",preferences:"Editor Preferences",broadcast:"Editor Event Broadcast",reference_image:"Reference Image Overlay",tool_management:"Tool Availability",setup_ui_layout:"Atomic UI Layout",import_and_apply_texture:"Import & Apply Texture",create_prefab_atomic:"Atomic Create Prefab",auto_fit_physics_collider:"Auto-Fit Physics Collider",create_tween_animation_atomic:"Atomic Create Animation",scene_generator:"AI Scene Generator",batch_engine:"Batch Operations Engine",scene_audit:"Scene Audit Tool"}},c={bridge_status:[],scene_query:["tree","list","stats","node_detail","find_by_path","get_components","get_parent","get_children","get_sibling","get_world_position","get_world_rotation","get_world_scale","get_active_in_hierarchy","find_nodes_by_name","find_nodes_by_component","get_component_property","get_node_components_properties","get_camera_info","get_canvas_info","get_scene_globals","get_current_selection","get_active_scene_focus","list_all_scenes","validate_scene","detect_2d_3d","list_available_components","measure_distance","scene_snapshot","scene_diff","performance_audit","export_scene_json","deep_validate_scene","get_node_bounds","find_nodes_by_layer","get_animation_state","get_collider_info","get_material_info","get_light_info","get_scene_environment","screen_to_world","world_to_screen","check_script_ready","get_script_properties"],scene_operation:["create_node","destroy_node","reparent","set_position","set_rotation","set_scale","set_world_position","set_world_rotation","set_world_scale","set_name","set_active","duplicate_node","move_node_up","move_node_down","set_sibling_index","reset_transform","add_component","remove_component","set_property","reset_property","call_component_method","ensure_2d_canvas","set_anchor_point","set_content_size","create_prefab","instantiate_prefab","enter_prefab_edit","exit_prefab_edit","apply_prefab","restore_prefab","validate_prefab","copy_node","paste_node","cut_node","move_array_element","remove_array_element","execute_component_method","lock_node","unlock_node","hide_node","unhide_node","set_layer","clear_children","reset_node_properties","batch","batch_set_property","group_nodes","align_nodes","clipboard_copy","clipboard_paste","create_ui_widget","setup_particle","audio_setup","setup_physics_world","create_skeleton_node","generate_tilemap","create_primitive","set_camera_look_at","set_camera_property","camera_screenshot","set_material_property","set_material_define","assign_builtin_material","assign_project_material","clone_material","swap_technique","sprite_grayscale","create_light","set_light_property","set_scene_environment","bind_event","unbind_event","list_events","attach_script","set_component_properties","detach_script"],asset_operation:["list","info","create","save","delete","move","copy","rename","import","open","refresh","create_folder","get_meta","set_meta_property","uuid_to_url","url_to_uuid","search_by_type","reimport","get_dependencies","get_dependents","show_in_explorer","clean_unused","pack_atlas","get_animation_clips","get_materials","validate_asset","export_asset_manifest","create_material","generate_script","batch_import","get_asset_size","slice_sprite"],editor_action:["save_scene","open_scene","new_scene","undo","redo","get_selection","select","clear_selection","project_info","preview","preview_refresh","build","build_query","play_in_editor","focus_node","log","warn","error","clear_console","show_notification","change_gizmo_tool","query_gizmo_tool_name","change_gizmo_pivot","query_gizmo_pivot","change_gizmo_coordinate","query_gizmo_coordinate","change_is2D","query_is2D","set_grid_visible","query_is_grid_visible","set_icon_gizmo_3d","query_is_icon_gizmo_3d","set_icon_gizmo_size","query_icon_gizmo_size","align_node_with_view","align_view_with_node","soft_reload","query_dirty","snapshot","snapshot_abort","cancel_recording","build_with_config","build_status","preview_status","send_message","open_panel","close_panel","query_panels","get_packages","reload_plugin","inspect_asset","open_preferences","open_project_settings","move_scene_camera","take_scene_screenshot","set_transform_tool","set_coordinate","toggle_grid","toggle_snap","get_console_logs","search_logs","set_view_mode","zoom_to_fit"],preferences:["get","set","list","get_global","set_global","get_project","set_project"],broadcast:["poll","history","clear","send","send_ipc"],tool_management:["list_all","enable","disable","get_stats"],execute_script:[],register_custom_macro:[],animation_tool:["create_clip","play","pause","resume","stop","get_state","list_clips","set_current_time","set_speed","crossfade"],physics_tool:["get_collider_info","add_collider","set_collider_size","add_rigidbody","set_rigidbody_props","set_physics_material","set_collision_group","get_physics_world","set_physics_world","add_joint"],create_prefab_atomic:[],import_and_apply_texture:[],setup_ui_layout:[],create_tween_animation_atomic:[],auto_fit_physics_collider:[],engine_action:["get_engine_info","set_engine_config","reload_scripts","clear_cache","gc","get_runtime_stats","set_design_resolution","get_supported_platforms"],reference_image:["add","remove","list","set_transform","set_opacity","toggle_visibility","clear_all"],scene_generator:["create_scene","create_ui_page","create_game_level","create_menu","describe_intent"],batch_engine:["find_and_modify","find_and_delete","find_and_add_component","find_and_remove_component","find_and_set_property","find_and_reparent","transform_all","rename_pattern","set_layer_recursive","toggle_active_recursive"],scene_audit:["full_audit","check_performance","check_hierarchy","check_components","check_assets","check_physics","check_ui","auto_fix","export_report"]},p=new Set(["engine_action","reference_image","scene_generator","batch_engine","scene_audit"]),S=["bridge_status","scene_query","scene_operation","asset_operation","editor_action","preferences","broadcast","tool_management","execute_script","register_custom_macro","animation_tool","physics_tool","create_prefab_atomic","import_and_apply_texture","setup_ui_layout","create_tween_animation_atomic","auto_fit_physics_collider","engine_action","reference_image","scene_generator","batch_engine","scene_audit"];e._toolEnabled={};try{e._toolEnabled=JSON.parse(localStorage.getItem("mcp-tool-enabled")||"{}")}catch{}let u="";function C(s,o,a){let g=e.$.toolToggleList;if(!g)return;let y=new Set(s||[]),$={};(s||[]).forEach(r=>{$[r]=new Set(o&&o[r]||[])});let x=[],T=new Set;S.forEach(r=>{T.has(r)||(x.push(r),T.add(r))}),(s||[]).forEach(r=>{T.has(r)||(x.push(r),T.add(r))});let D=JSON.stringify({mergedNames:x,toolActions:o,toolStates:a,currentLang:i});if(D===u&&g.children.length>0)return;u=D;let K="",W=g.querySelector(".tool-row.expanded");if(W){let r=W.querySelector(".tool-toggle");r&&(K=r.getAttribute("data-tool")||"")}g.textContent="";let ae=t[i]||t.zh,ne=d[i]||d.zh,q=i==="zh"?"Pro 版专属":"Pro Exclusive",oe=i==="zh"?"升级 Pro 解锁":"Upgrade to Pro";x.forEach(r=>{let _=y.has(r),b=!_&&p.has(r),ce=p.has(r),Q=m.includes(r),re=_?a&&Object.prototype.hasOwnProperty.call(a,r)?!!a[r]:e._toolEnabled[r]!==!1:!1,E=o&&o[r]||[],k=c[r]||[],N=k.length>0?k:E,J=$[r]||new Set,G=_&&k.length>E.length,R=document.createElement("div");R.className="tool-wrapper";let h=document.createElement("div");h.className="tool-row"+(b?" pro-locked":"");let P=document.createElement("div");P.className="tool-info";let L=document.createElement("div");L.className="tool-name-row";let O=document.createElement("span");if(O.className="tool-name"+(b?" pro-locked-text":""),O.textContent=r,Q){let n=document.createElement("span");n.className="core-badge",n.textContent=ae["ctrl.tools_core"]||"(core)",O.appendChild(n)}if(L.appendChild(O),b){let n=document.createElement("span");n.className="pro-badge",n.textContent="PRO",L.appendChild(n)}else if(G){let n=document.createElement("span");n.className="pro-extra-badge",n.textContent=i==="zh"?`+${k.length-E.length} Pro`:`+${k.length-E.length} Pro`,L.appendChild(n)}if(N.length>0){let n=document.createElement("span");n.className="action-count-badge"+(b?" pro-locked-text":""),n.textContent=_&&G?E.length+"/"+k.length:String(N.length),n.title=_&&G?i==="zh"?`社区版 ${E.length} / Pro 版 ${k.length} actions`:`Community ${E.length} / Pro ${k.length} actions`:N.length+" actions",L.appendChild(n)}P.appendChild(L);let U=ne[r];if(U){let n=document.createElement("span");n.className="tool-desc"+(b?" pro-locked-text":""),n.textContent=b?U+" — "+q:U,P.appendChild(n)}if(b){let n=document.createElement("span");n.className="pro-lock-icon",n.textContent="🔒",n.title=q,h.appendChild(P),h.appendChild(n)}else{let n=document.createElement("input");n.type="checkbox",n.className="tool-toggle",n.setAttribute("data-tool",r),n.checked=re,n.disabled=Q,h.appendChild(P),h.appendChild(n)}if(R.appendChild(h),N.length>0){let n=document.createElement("div");n.className="action-panel",n.setAttribute("data-tool",r),r===K&&(n.classList.add("open"),h.classList.add("expanded"));let F=document.createElement("div");F.className="action-grid",N.forEach(I=>{let B=document.createElement("span"),M=_&&J.has(I),Y=_&&!J.has(I);B.className="action-chip"+(b?" action-chip-locked":"")+(Y?" action-chip-pro":""),B.textContent=I,Y&&(B.title=oe),b&&(B.title=q),F.appendChild(B)}),n.appendChild(F),R.appendChild(n),h.style.cursor="pointer",h.addEventListener("click",I=>{if(I.target.classList&&I.target.classList.contains("tool-toggle"))return;let B=n.classList.contains("open");g.querySelectorAll(".action-panel").forEach(M=>{M.classList.remove("open")}),g.querySelectorAll(".tool-row").forEach(M=>{M.classList.remove("expanded")}),B||(n.classList.add("open"),h.classList.add("expanded"))})}g.appendChild(R)}),g.querySelectorAll(".tool-toggle").forEach(r=>{r.addEventListener("change",_=>{let b=_.target.getAttribute("data-tool");e._toolEnabled[b]=_.target.checked;try{localStorage.setItem("mcp-tool-enabled",JSON.stringify(e._toolEnabled))}catch{}Editor.Message.send(f,"set-tool-enabled",b,_.target.checked)})})}e._renderToolToggles=C,e._applyI18n=l;let v=e.$.app.querySelectorAll(".mcp-tab"),A=e.$.app.querySelectorAll(".mcp-tab-content"),w=e.$.app.querySelector(".tab-indicator"),z=e.$.app.querySelector(".mcp-tabs-header");function V(s){if(!w||!z||!s)return;let o=z.getBoundingClientRect(),a=s.getBoundingClientRect();w.style.left=a.left-o.left+"px",w.style.width=a.width+"px"}requestAnimationFrame(()=>{let s=e.$.app.querySelector(".mcp-tab.active");s&&V(s)}),v.forEach(s=>{s.addEventListener("click",()=>{v.forEach(y=>y.classList.remove("active")),A.forEach(y=>y.classList.remove("active")),s.classList.add("active"),V(s);let o=s.getAttribute("data-target"),a=e.$.app.querySelector(`#${o}`);a&&a.classList.add("active");let g=e.$.app.querySelector(".mcp-tabs-container");g&&(g.scrollTop=0)})}),e.$.startBtn.addEventListener("click",()=>{Editor.Message.send(f,"start-server"),setTimeout(()=>e.refreshStatus(),1e3),setTimeout(()=>e.refreshStatus(),2500)});let X=null;e.$.stopBtn.addEventListener("click",()=>{e.$.stopBtn.classList.contains("confirming")?(clearTimeout(X),e.$.stopBtn.classList.remove("confirming"),e.$.stopBtn.textContent="■ 停止服务",Editor.Message.send(f,"stop-server"),setTimeout(()=>e.refreshStatus(),800)):(e.$.stopBtn.classList.add("confirming"),e.$.stopBtn.textContent="⚠ 确认停止？",X=setTimeout(()=>{e.$.stopBtn.classList.remove("confirming"),e.$.stopBtn.textContent="■ 停止服务"},2500))}),e.$.restartBtn.addEventListener("click",()=>{Editor.Message.send(f,"restart-server"),setTimeout(()=>e.refreshStatus(),1e3)}),e.$.app.querySelectorAll(".config-ide-btn").forEach(s=>{s.addEventListener("click",async o=>{let a=o.currentTarget,g=a&&a.getAttribute?a.getAttribute("data-ide"):null,y=a&&"textContent"in a?a.textContent:"注入配置";if(!a||!g){e.showConfigResult({success:!1,message:"配置失败: 无法识别目标 IDE"});return}a.setAttribute("disabled",""),a.textContent="⏳ Inject...";let $="inject-fail";try{let x=await Promise.race([Editor.Message.request(f,"configure-ide",g),new Promise((T,D)=>setTimeout(()=>D(new Error("请求超时，请重试")),1e4))]);e.showConfigResult(x),$=x.success?"inject-success":"inject-fail",setTimeout(()=>e.refreshStatus(),500)}catch(x){e.showConfigResult({success:!1,message:`配置失败: ${x.message||x}`})}finally{a.removeAttribute("disabled"),a.textContent=y,a.classList.add($),setTimeout(()=>a.classList.remove($),2e3)}})}),e.$.settingLoopback.addEventListener("change",()=>{e.$.loopbackWarn.style.display=e.$.settingLoopback.checked?"none":"block"}),e.$.saveSettingsBtn.addEventListener("click",async()=>{let s=t[i]||t.zh;try{let o={rateLimitPerMinute:parseInt(e.$.settingRateLimit.value,10)||240,loopbackOnly:e.$.settingLoopback.checked,maxBodySizeBytes:parseInt(e.$.settingBodyLimit.value,10)||1048576,autoRollback:e.$.settingRollback.checked};await Editor.Message.request(f,"update-settings",o),e.showSettingsResult(!0,s["settings.saved"]||"Settings saved")}catch(o){e.showSettingsResult(!1,`${s["cfg.fail"]||"Failed"}: ${o.message||o}`)}}),e.$.resetSettingsBtn.addEventListener("click",async()=>{let s=t[i]||t.zh;try{let o=await Editor.Message.request(f,"reset-settings");o&&o.settings&&e.applySettingsToUI(o.settings),e.showSettingsResult(!0,s["settings.reset_done"]||"Settings reset to defaults")}catch(o){e.showSettingsResult(!1,`${s["cfg.fail"]||"Failed"}: ${o.message||o}`)}}),e.$.activateLicenseBtn.addEventListener("click",async()=>{let s=e.$.licenseKeyInput.value.trim();if(!s)return;let o=t[i]||t.zh;e.$.activateLicenseBtn.setAttribute("disabled",""),e.$.activateLicenseBtn.textContent="...";try{let a=await Promise.race([Editor.Message.request(f,"activate-license",s),new Promise((g,y)=>setTimeout(()=>y(new Error(o["cfg.timeout"]||"Timeout")),1e4))]);a&&a.licenseStatus&&e.updateLicenseUI(a.licenseStatus),a&&a.success?e.showSettingsResult(!0,o["settings.license_activated"]||"License activated! Restart plugin for Pro tools."):e.showSettingsResult(!1,a?.error||o["settings.license_invalid"]||"Invalid license key")}catch(a){e.showSettingsResult(!1,`${a.message||a}`)}finally{e.$.activateLicenseBtn.removeAttribute("disabled"),e.$.activateLicenseBtn.textContent=o["settings.activate"]||"激活"}}),e.$.app.querySelectorAll(".prompt-copy").forEach(s=>{s.addEventListener("click",()=>{let a=s.closest(".prompt-card")?.querySelector(".prompt-text")?.textContent||"";navigator.clipboard&&navigator.clipboard.writeText(a).then(()=>{s.textContent="✓",s.classList.add("copied"),setTimeout(()=>{s.textContent="📋",s.classList.remove("copied")},1500)})})});function H(s){s&&(s.classList.add("copyable"),s.style.position="relative",s.addEventListener("click",()=>{let o=s.textContent;!o||o==="-"||navigator.clipboard&&navigator.clipboard.writeText(o).then(()=>{let a=document.createElement("span");a.className="copy-toast",a.textContent="已复制",s.appendChild(a),setTimeout(()=>a.remove(),1e3)})}))}H(e.$.portValue),H(e.$.endpointValue),e.$.updateBtn.addEventListener("click",()=>{let s=e.$.app.querySelector('[data-target="tabStatus"]');s&&s.click(),e.$.updateBanner&&(e.$.updateBanner.style.display="flex",e.$.updateBanner.scrollIntoView({behavior:"smooth",block:"nearest"}))}),e.$.refreshBtn.addEventListener("click",()=>{e.$.refreshBtn.classList.remove("spinning"),e.$.refreshBtn.offsetWidth,e.$.refreshBtn.classList.add("spinning"),e.refreshStatus(),setTimeout(()=>e.$.refreshBtn.classList.remove("spinning"),700)}),requestAnimationFrame(()=>{e.refreshStatus(),j=setInterval(()=>e.refreshStatus(),3e3)})},close(){j&&(clearInterval(j),j=null)},methods:{formatUptime(e){if(!e||e<=0)return"-";let t=Math.floor(e/3600),i=Math.floor(e%3600/60),l=e%60;return`${String(t).padStart(2,"0")}:${String(i).padStart(2,"0")}:${String(l).padStart(2,"0")}`},updateWithFlash(e,t){if(!e)return;let i=String(t);e.textContent!==i&&(e.textContent=i,e.classList.remove("value-changed"),e.offsetWidth,e.classList.add("value-changed"))},async refreshStatus(){let e=this;try{let t=await Editor.Message.request(f,"get-service-info");if(t&&t.running){if(e.$.statusDot.className="status-dot online",e.$.statusText.className="status-text online",e.$.statusText.textContent="Online",e.$.startBtn.classList.add("btn-disabled"),e.$.stopBtn.classList.remove("btn-disabled"),e.$.ctrlStatusLabel.textContent="运行中",e.$.ctrlStatusLabel.style.color="#22c55e",e.$.bentoGrid.classList.remove("loading"),e.$.bentoGrid.style.display="",e.$.emptyState.style.display="none",e.$.portValue.textContent=String(t.port),e.$.endpointValue.textContent=t.bridgeBase?`${t.bridgeBase}/mcp`:"-",e.$.projectName.textContent=t.projectName||"-",e.$.projectPath.textContent=t.projectPath||"-",e.$.editorVersion.textContent=t.editorVersion||"-",e.updateWithFlash(e.$.connectionCount,t.connectionCount??0),e.updateWithFlash(e.$.toolCount,t.toolCount??0),e.updateWithFlash(e.$.totalActionCount,t.totalActionCount??0),e.updateWithFlash(e.$.uptime,e.formatUptime(t.uptime??0)),t.allToolNames&&t.toolEnabledStates&&(e._toolEnabled={...e._toolEnabled,...t.toolEnabledStates}),(t.allToolNames||t.toolNames)&&e._renderToolToggles&&e._renderToolToggles(t.allToolNames||t.toolNames,t.toolActions||{},t.toolEnabledStates||{}),t.settings&&e.applySettingsToUI(t.settings),t.configStatus){let i=(l,m)=>{let d=e.$[l];d.textContent=m?"配置已就绪":"未检测到配置",d.className=`ide-status ${m?"ready":"unready"}`};i("statusCursor",t.configStatus.cursor),i("statusWindsurf",t.configStatus.windsurf),i("statusClaude",t.configStatus.claude),i("statusTrae",t.configStatus.trae),i("statusKiro",t.configStatus.kiro),i("statusAntigravity",t.configStatus.antigravity),i("statusGeminiCli",t.configStatus["gemini-cli"]),i("statusCodex",t.configStatus.codex),i("statusClaudeCode",t.configStatus["claude-code"]),i("statusCodebuddy",t.configStatus.codebuddy),i("statusComate",t.configStatus.comate)}}else e.setOffline();t&&t.licenseStatus&&e.updateLicenseUI(t.licenseStatus),t&&t.updatePhase&&e.renderUpdateBanner(t.updatePhase)}catch(t){console.warn("[Aura] refreshStatus 异常:",t),e.setOffline()}},setOffline(){let e=this;e.$.statusDot.className="status-dot offline",e.$.statusText.className="status-text offline",e.$.statusText.textContent="Offline",e.$.startBtn.classList.remove("btn-disabled"),e.$.stopBtn.classList.add("btn-disabled"),e.$.ctrlStatusLabel.textContent="已停止",e.$.ctrlStatusLabel.style.color="#ef4444",e.$.bentoGrid.classList.remove("loading"),e.$.bentoGrid.style.display="none",e.$.emptyState.style.display="flex",e.$.portValue.textContent="-",e.$.endpointValue.textContent="-",e.$.projectName.textContent="-",e.$.projectPath.textContent="-",e.$.editorVersion.textContent="-",e.$.connectionCount.textContent="-",e.$.toolCount.textContent="-",e.$.totalActionCount.textContent="-",e.$.uptime.textContent="-"},showConfigResult(e){let t=this,i=t.$.configResult;i.style.display="flex",i.className=`config-result ${e.success?"success":"error"}`,t.$.configIcon.textContent=e.success?"✓":"✗",t.$.configMessage.textContent=e.message||""},applySettingsToUI(e){let t=this;e&&(typeof e.rateLimitPerMinute=="number"&&(t.$.settingRateLimit.value=String(e.rateLimitPerMinute)),typeof e.loopbackOnly=="boolean"&&(t.$.settingLoopback.checked=e.loopbackOnly,t.$.loopbackWarn.style.display=e.loopbackOnly?"none":"block"),typeof e.maxBodySizeBytes=="number"&&(t.$.settingBodyLimit.value=String(e.maxBodySizeBytes)),typeof e.autoRollback=="boolean"&&(t.$.settingRollback.checked=e.autoRollback))},showSettingsResult(e,t){let i=this,l=i.$.settingsResult;l.style.display="flex",l.className=`config-result ${e?"success":"error"}`,i.$.settingsIcon.textContent=e?"✓":"✗",i.$.settingsMessage.textContent=t||"",setTimeout(()=>{l.style.display="none"},3e3)},renderUpdateBanner(e){let t=this,i=t.$.updateBanner,l=t.$.updateBtn;if(!i||!e)return;let m=t._I18N&&t._I18N[t._currentLang]||{},d=(c,p)=>m[c]||p;if(e.phase==="idle"||e.phase==="checking"||e.phase==="up-to-date"){i.style.display="none",l&&(l.style.display="none");return}if(i.style.display="flex",l&&(l.style.display="inline-flex"),e.phase==="available"){let c=e.info||{},p=`<div class="update-header"><span class="update-title">${d("update.available","🎉 新版本可用")}</span></div>`;p+=`<div class="update-ver-row">
          <span class="update-ver-label">${d("update.current","当前")}:</span>
          <span class="update-ver-value">${c.currentVersion||"-"}</span>
          <span class="update-arrow">→</span>
          <span class="update-ver-label">${d("update.latest","最新")}:</span>
          <span class="update-ver-value">${c.latestVersion||"-"}</span>
        </div>`,c.changelog&&(p+=`<div class="update-changelog">${c.changelog}</div>`),c.breaking&&(p+=`<div class="update-breaking">${d("update.breaking","⚠ 重要更新，建议备份后升级")}</div>`),p+=`<div class="update-actions">
          <button class="btn btn-primary" id="doDownloadBtn" style="padding:6px 14px;font-size:12px;">${d("update.download","立即下载")}</button>
        </div>`,i.innerHTML=p;let S=i.querySelector("#doDownloadBtn");S&&S.addEventListener("click",()=>{t.handleDownloadUpdate(S)});return}if(e.phase==="downloading"||e.phase==="verifying"){let c=e.phase==="verifying"?100:e.progress||0,p=e.phase==="verifying"?d("update.verifying","校验中..."):`${d("update.downloading","下载中")} ${c}%`;i.innerHTML=`
          <div class="update-header"><span class="update-title">${p}</span></div>
          <div class="update-progress-wrap">
            <div class="update-progress-bar">
              <div class="update-progress-fill" style="width:${c}%"></div>
            </div>
            <span class="update-progress-text">${c}%</span>
          </div>`;return}if(e.phase==="ready"){let c=e.info||{};i.innerHTML=`
          <div class="update-header"><span class="update-title">${d("update.available","🎉 新版本可用")} v${c.latestVersion||""}</span></div>
          <div class="update-progress-wrap">
            <div class="update-progress-bar"><div class="update-progress-fill" style="width:100%"></div></div>
            <span class="update-progress-text">✓ 下载完成，SHA256 校验通过</span>
          </div>
          <div class="update-actions">
            <button class="btn btn-primary" id="doInstallBtn" style="padding:6px 14px;font-size:12px;">${d("update.install","安装并重启")}</button>
          </div>`;let p=i.querySelector("#doInstallBtn");p&&p.addEventListener("click",()=>{t.handleInstallUpdate(p)});return}if(e.phase==="installing"){i.innerHTML=`<div class="update-header"><span class="update-title">${d("update.installing","安装中...")}</span></div>
          <div class="update-progress-wrap">
            <div class="update-progress-bar"><div class="update-progress-fill" style="width:100%;animation:updatePulse 1s infinite"></div></div>
          </div>`;return}if(e.phase==="done"){i.innerHTML=`<div class="update-done-msg">${d("update.done","✅ 更新完成，请重启 Cocos Creator 生效")}</div>`,l&&(l.style.display="none");return}if(e.phase==="error"){i.innerHTML=`
          <div class="update-error-msg">✗ ${d("update.error","更新失败")}: ${e.message||""}</div>
          <div class="update-actions">
            <button class="btn" id="doRetryBtn" style="padding:5px 12px;font-size:11px;">${d("update.retry","重试")}</button>
          </div>`;let c=i.querySelector("#doRetryBtn");c&&c.addEventListener("click",async()=>{await Editor.Message.request(f,"reset-update-state"),await Editor.Message.request(f,"check-for-updates"),setTimeout(()=>t.refreshStatus(),500)});return}},async handleDownloadUpdate(e){let t=this;e&&(e.setAttribute("disabled",""),e.textContent="下载中...");try{await Editor.Message.request(f,"download-update")}catch(i){console.error("[Aura] 下载更新失败:",i)}},async handleInstallUpdate(e){let t=this;e&&(e.setAttribute("disabled",""),e.textContent="安装中...");try{await Editor.Message.request(f,"install-update")}catch(i){console.error("[Aura] 安装更新失败:",i)}},updateLicenseUI(e){let t=this;if(!e)return;t._lastLicenseStatus=e;let{proInstalled:i,licenseValid:l,edition:m,expiry:d,licensedTo:c,error:p}=e,S=t._I18N&&t._I18N[t._currentLang]||{},u=(w,z)=>S[w]||z,C=t.$.holoBadge&&t.$.holoBadge.querySelector(".holo-badge-inner"),v=t.$.licenseCard&&t.$.licenseCard.querySelector(".license-input-row"),A=t.$.licenseCard&&t.$.licenseCard.querySelector(".license-hint");if(l&&m&&m!=="community"){let w=m==="enterprise"?u("license.enterprise_edition","Enterprise Edition"):u("license.pro_edition","Pro Edition");t.$.licenseEdition.textContent=w,t.$.licenseState.textContent=u("license.activated","Activated"),t.$.licenseState.className="license-state active",t.$.licenseDetail.style.display="flex",t.$.licenseExpiry.textContent=d?`${u("license.expiry_prefix","Valid until")} ${d}`:"",t.$.licenseOwner.textContent=c?`Licensed to: ${c}`:"",t.$.licenseError.style.display="none",v&&(v.style.display="flex"),A&&(A.style.display="block"),C&&(C.textContent=m==="enterprise"?u("badge.enterprise","Enterprise"):u("badge.pro","Pro"))}else i&&!l?(t.$.licenseEdition.textContent=u("license.pro_edition","Pro Edition"),p&&p.includes("expired")?(t.$.licenseState.textContent=u("license.expired","Expired"),t.$.licenseState.className="license-state expired"):(t.$.licenseState.textContent=u("license.not_activated","Not Activated"),t.$.licenseState.className="license-state no-key"),t.$.licenseDetail.style.display="none",p?(t.$.licenseError.style.display="block",t.$.licenseError.textContent=p):t.$.licenseError.style.display="none",v&&(v.style.display="flex"),A&&(A.style.display="block"),C&&(C.textContent=u("badge.pro","Pro"))):(t.$.licenseEdition.textContent=u("license.community_edition","Community Edition"),t.$.licenseState.textContent=u("license.free","Free"),t.$.licenseState.className="license-state community",t.$.licenseDetail.style.display="none",t.$.licenseError.style.display="none",v&&(v.style.display="none"),A&&(A.style.display="none"),C&&(C.textContent=u("badge.community","Community")))}}});
